<main>
			
			<!-- Page Header -->
			<div class="container-fluid no-padding page-header">
				<div class="container">
					<ol class="breadcrumb">
						<li><a href="#">kilitreksafari</a></li>
						<li class="active">about</li>
					</ol>
				</div>
			</div><!-- Page Header /- -->
			
			<!-- About Section -->
			<div id="about-section" class="container-fluid no-left-padding no-right-padding about-section">
				<!-- About Image -->
				<div class="col-md-6 col-am-12 no-padding about-img" data-image="<?=base_url('assets/images/about-img.jpg');?>">
				</div><!-- About Image /- -->
				<!-- About Content -->
				<div class="col-md-6 col-sm-12 about-content">
					<!-- Section Header -->
					<div class="section-header">
						<h3>We Share Something</h3>
						<h6>About us</h6>
					</div><!-- Section Header /- -->
					<div class="about-content-box">
						<h4>The mate was a mighty sailin man the Skipper brave and sure. Five passegers set sail.</h4>
						<p>The Love Boat soon will be making another run. The Love Boat promises something for everyone. who wabusy with three boys of his own. Sunny Days sweepin' the clouds away. On my way to where the air is sweet. Can you tell me how to get how to get to Sesame Street The mate  a mighty sailin' man the  Skipper brave and sure. Five passengers set sail that day for a three hour tour a  three hour tour. Till the one day when the lady met this fellow more than a hunch.</p>
						<a href="#" title="About More">About More</a>
					</div>
				</div><!-- About Content /- -->
			</div><!-- About Section /- -->
			
			<!-- Team Section -->
			<div id="team-section" class="container-fluid no-left-padding no-right-padding team-section">
				<!-- Container -->
				<div class="container">
					<!-- Section Header -->
					<div class="section-header">
						<h3>Great Guidelines</h3>
						<h6>our team</h6>
					</div><!-- Section Header /- -->
					<div class="row">
						<div class="team-carousel">
							<!-- Team Box -->
							<div class="col-md-12 col-sm-12 col-xs-12 team-box">
								<div class="team-content">
									<img src="<?=base_url('assets/images/team-1.jpg'); ?>" alt="Team" />
									<div class="team-content-box">
										<i class="fa fa-male"></i>
										<h3>john smith <span>(Hiking Guide)</span></h3>
										<ul>
											<li><a href="#" title="Facebook"><i class="fa fa-facebook"></i></a></li>
											<li><a href="#" title="Twitter"><i class="fa fa-twitter"></i></a></li>
											<li><a href="#" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
											<li><a href="#" title="Tumblr"><i class="fa fa-tumblr"></i></a></li>
											<li><a href="#" title="Vimeo"><i class="fa fa-vimeo"></i></a></li>
											<li><a href="#" title="Pinterest"><i class="fa fa-pinterest-p"></i></a></li>
										</ul>
									</div>
								</div>
							</div><!-- Team Box /- -->
							<!-- Team Box -->
							<div class="col-md-12 col-sm-12 col-xs-12 team-box">
								<div class="team-content">
									<img src="<?=base_url('assets/images/team-2.jpg'); ?>" alt="Team" />
									<div class="team-content-box">
										<i class="fa fa-compass"></i>
										<h3>james warner <span>(Travel Guide)</span></h3>
										<ul>
											<li><a href="#" title="Facebook"><i class="fa fa-facebook"></i></a></li>
											<li><a href="#" title="Twitter"><i class="fa fa-twitter"></i></a></li>
											<li><a href="#" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
											<li><a href="#" title="Tumblr"><i class="fa fa-tumblr"></i></a></li>
											<li><a href="#" title="Vimeo"><i class="fa fa-vimeo"></i></a></li>
											<li><a href="#" title="Pinterest"><i class="fa fa-pinterest-p"></i></a></li>
										</ul>
									</div>
								</div>
							</div><!-- Team Box /- -->
							<!-- Team Box -->
							<div class="col-md-12 col-sm-12 col-xs-12 team-box">
								<div class="team-content">
									<img src="<?=base_url('assets/images/team-3.jpg'); ?>" alt="Team" />
									<div class="team-content-box">
										<i class="icon_cone_alt"></i>
										<h3>Peter parker <span>(Mountain Guide)</span></h3>
										<ul>
											<li><a href="#" title="Facebook"><i class="fa fa-facebook"></i></a></li>
											<li><a href="#" title="Twitter"><i class="fa fa-twitter"></i></a></li>
											<li><a href="#" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
											<li><a href="#" title="Tumblr"><i class="fa fa-tumblr"></i></a></li>
											<li><a href="#" title="Vimeo"><i class="fa fa-vimeo"></i></a></li>
											<li><a href="#" title="Pinterest"><i class="fa fa-pinterest-p"></i></a></li>
										</ul>
									</div>
								</div>
							</div><!-- Team Box /- -->
							<!-- Team Box -->
							<div class="col-md-12 col-sm-12 col-xs-12 team-box">
								<div class="team-content">
									<img src="<?=base_url('assets/images/team-2.jpg'); ?>" alt="Team" />
									<div class="team-content-box">
										<i class="fa fa-male"></i>
										<h3>john smith <span>(Hiking Guide)</span></h3>
										<ul>
											<li><a href="#" title="Facebook"><i class="fa fa-facebook"></i></a></li>
											<li><a href="#" title="Twitter"><i class="fa fa-twitter"></i></a></li>
											<li><a href="#" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
											<li><a href="#" title="Tumblr"><i class="fa fa-tumblr"></i></a></li>
											<li><a href="#" title="Vimeo"><i class="fa fa-vimeo"></i></a></li>
											<li><a href="#" title="Pinterest"><i class="fa fa-pinterest-p"></i></a></li>
										</ul>
									</div>
								</div>
							</div><!-- Team Box /- -->
						</div>
					</div>
				</div><!-- Container /- -->
			</div><!-- Team Section /- -->
			
		</main>
