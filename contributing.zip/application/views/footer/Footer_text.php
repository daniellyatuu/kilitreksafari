<!-- Footer Section -->
<footer class="footer-main" style="padding: 0; margin: 0;">
<!-- Footer Bottom -->
<div class="container-fluid no-padding btm-ftr">
	<div class="container">
		<p>kilitreksafari <i class="fa fa-copyright"></i> <?=Date('Y');?>.  All Rights Reserved.</p>
	</div>
</div><!-- Footer Bottom /- -->
</footer><!-- Footer Section /- -->