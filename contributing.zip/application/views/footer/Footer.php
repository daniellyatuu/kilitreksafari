</div>

	<!-- JQuery v1.12.4 -->
	<script src="<?=base_url('assets/js/jquery-1.12.4.min.js'); ?>"></script>

	<!-- Library - Js -->
	<script src="<?=base_url('assets/libraries/lib.js'); ?>"></script>
		
	<!-- RS5.0 Core JS Files -->
	<script type="text/javascript" src="<?=base_url('assets/revolution/js/jquery.themepunch.tools.min838f.js?rev=5.0'); ?>"></script>
	<script type="text/javascript" src="<?=base_url('assets/revolution/js/jquery.themepunch.revolution.min838f.js?rev=5.0'); ?>"></script>
	<script type="text/javascript" src="<?=base_url('assets/revolution/js/extensions/revolution.extension.actions.min.js'); ?>"></script>
	<script type="text/javascript" src="<?=base_url('assets/revolution/js/extensions/revolution.extension.carousel.min.js'); ?>"></script>
	<script type="text/javascript" src="<?=base_url('assets/revolution/js/extensions/revolution.extension.kenburn.min.js'); ?>"></script>
	<script type="text/javascript" src="<?=base_url('assets/revolution/js/extensions/revolution.extension.layeranimation.min.js'); ?>"></script>
	<script type="text/javascript" src="<?=base_url('assets/revolution/js/extensions/revolution.extension.migration.min.js'); ?>"></script>
	<script type="text/javascript" src="<?=base_url('assets/revolution/js/extensions/revolution.extension.navigation.min.js'); ?>"></script>
	<script type="text/javascript" src="<?=base_url('assets/revolution/js/extensions/revolution.extension.parallax.min.js'); ?>"></script>
	<script type="text/javascript" src="<?=base_url('assets/revolution/js/extensions/revolution.extension.slideanims.min.js'); ?>"></script>
	<script type="text/javascript" src="<?=base_url('assets/revolution/js/extensions/revolution.extension.video.min.js'); ?>"></script>

	<!-- Library - Theme JS -->
	<script src="<?=base_url('assets/js/functions.js'); ?>"></script>
	
</body>

<!-- Mirrored from premiumlayers.net/demo/html/hiking/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 16 Apr 2020 09:09:13 GMT -->
</html>
